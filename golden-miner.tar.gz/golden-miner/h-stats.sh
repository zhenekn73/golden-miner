####################################################################################
###
### golden-miner
###
####################################################################################

#!/usr/bin/env bash

#######################
# Helpers
#######################

# Load manifest to get CUSTOM_MINERBIN, CUSTOM_* vars
. /hive/miners/custom/golden-miner/h-manifest.conf

# Find the golden-miner process PID (golden-miner-pool-prover)
get_miner_pid() {
  local pid
  pid=$(pgrep -f "$CUSTOM_MINERBIN" | head -n 1)
  echo "$pid"
}

# Read CUDA_VISIBLE_DEVICES from miner env, e.g. "6,7,8,9,10,11"
get_cuda_visible_devices() {
  local pid
  pid=$(get_miner_pid)
  if [[ -z "$pid" || ! -r "/proc/$pid/environ" ]]; then
    echo ""
    return
  fi

  tr '\0' '\n' < "/proc/$pid/environ" \
    | grep '^CUDA_VISIBLE_DEVICES=' \
    | head -n 1 \
    | cut -d '=' -f 2
}

#######################
# MAIN script body
#######################

LOG_FILE="$CUSTOM_LOG_BASENAME.log"

stats_raw=$(grep -w "speed" "$LOG_FILE" | tail -n 1)
echo "stats_raw: $stats_raw"

# Calculate miner log freshness
maxDelay=120
time_now=$(date -u +%s)  # UTC
echo "time_now : $time_now"

datetime_rep=$(echo "$stats_raw" | awk '{print $1}' | cut -d '.' -f1 | sed 's/T/ /; s/Z//')
time_rep=$(date -u -d "$datetime_rep" +%s 2>/dev/null || echo 0)  # UTC

diffTime=$((time_now - time_rep))
diffTime=$(echo "$diffTime" | tr -d '-')  # absolute value
echo "diffTime : $diffTime"

if [ "$diffTime" -lt "$maxDelay" ] && [[ -n "$stats_raw" ]]; then
  total_hashrate=$(echo "$stats_raw" | awk '{print $5}' | cut -d "." -f 1,2 --output-delimiter='' | sed 's/$/0/')
  echo "total_hashrate : $total_hashrate"

  # GPU Status
  echo "GPU_STATS_JSON=$GPU_STATS_JSON" >&2
  ls -l "$GPU_STATS_JSON" >&2 || true
  jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" >&2 || true

  readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" 2>/dev/null )
  busids=(${gpu_stats[0]})
  brands=(${gpu_stats[1]})
  temps=(${gpu_stats[2]})
  fans=(${gpu_stats[3]})
  gpu_count=${#busids[@]}

  busid_arr=()
  fan_arr=()
  temp_arr=()
  disc_indices=()   # list of "discrete GPU indices" (excluding 'cpu')
  total_hashrate_sum=0

  # Build arrays of discrete GPUs (skip 'cpu'), in the same order Hive uses for GPUs
  for (( i=0; i<gpu_count; i++ )); do
    if [[ "${brands[i]}" == "cpu" ]]; then
      continue
    fi

    # Convert busid hex to decimal
    if [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]; then
      busid_arr+=( $((16#${BASH_REMATCH[1]})) )
    else
      busid_arr+=( 0 )
    fi

    temp_arr+=( "${temps[i]}" )
    fan_arr+=( "${fans[i]}" )

    # This position corresponds to discrete GPU index "disc_idx"
    disc_indices+=( "$i" )  # keep original index if ever needed
  done

  disc_count=${#disc_indices[@]}

  # Prepare final hash array aligned with busid_arr / temp_arr / fan_arr
  final_hash_arr=()
  for (( j=0; j<disc_count; j++ )); do
    final_hash_arr[j]=0
  done

  # Read CUDA_VISIBLE_DEVICES from running miner (if any)
  cuda_map_str=$(get_cuda_visible_devices)
  echo "CUDA_VISIBLE_DEVICES: ${cuda_map_str:-none}" >&2

  if [[ -n "$cuda_map_str" ]]; then
    # Example: "6,7,8,9,10,11"
    IFS=',' read -r -a cuda_map <<< "$cuda_map_str"
    vis_count=${#cuda_map[@]}

    # Each local card index maps to a discrete GPU index from cuda_map
    for (( local_idx=0; local_idx<vis_count; local_idx++ )); do
      disc_idx="${cuda_map[$local_idx]}"

      # Bound check: disc_idx must be in [0, disc_count-1]
      if (( disc_idx < 0 || disc_idx >= disc_count )); then
        continue
      fi

      gpu_raw=$(grep -w "Card-$local_idx speed" "$LOG_FILE" | tail -n 1 | tr -d '\000')
      echo "gpu_raw (local_idx=$local_idx, disc_idx=$disc_idx): $gpu_raw"

      hashrate=$(echo "$gpu_raw" | awk '{print $(NF-1)}' | tr -d '\000' | cut -d "." -f1,2 --output-delimiter='' | sed 's/$/0/')
      [[ -z "$hashrate" ]] && hashrate=0
      echo "hashrate: $hashrate"

      final_hash_arr[$disc_idx]="$hashrate"
      total_hashrate_sum=$((total_hashrate_sum + hashrate))
    done

  else
    # No CUDA_VISIBLE_DEVICES: assume Card-j corresponds to discrete GPU j
    for (( disc_idx=0; disc_idx<disc_count; disc_idx++ )); do
      gpu_raw=$(grep -w "Card-$disc_idx speed" "$LOG_FILE" | tail -n 1 | tr -d '\000')
      echo "gpu_raw (disc_idx=$disc_idx): $gpu_raw"

      hashrate=$(echo "$gpu_raw" | awk '{print $(NF-1)}' | tr -d '\000' | cut -d "." -f1,2 --output-delimiter='' | sed 's/$/0/')
      [[ -z "$hashrate" ]] && hashrate=0
      echo "hashrate: $hashrate"

      final_hash_arr[$disc_idx]="$hashrate"
      total_hashrate_sum=$((total_hashrate_sum + hashrate))
    done
  fi

  # Build JSON from final_hash_arr and busid/temp/fan arrays
  hash_json=$(printf '%s\n' "${final_hash_arr[@]}" | jq -cs '.')
  bus_numbers=$(printf '%s\n' "${busid_arr[@]}"  | jq -cs '.')
  fan_json=$(printf '%s\n' "${fan_arr[@]}"  | jq -cs '.')
  temp_json=$(printf '%s\n' "${temp_arr[@]}"  | jq -cs '.')

  ########################
  # Accepted / rejected shares (from alternative script)
  ########################
  accepted_shares=0
  rejected_shares=0

  if [[ -f "$LOG_FILE" ]]; then
    # Same pattern you showed: count "INFO  Heartbeat success"
    accepted_shares=$(awk '/INFO[[:space:]]+Heartbeat success/ {count++} END {print count+0}' "$LOG_FILE")
    # You can later add a pattern here for rejected_shares if your miner logs them
    # e.g. rejected_shares=$(grep -c "invalid share" "$LOG_FILE")
  fi

  # Uptime (your original logic: config mtime)
  uptime=$(( $(date +%s) - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME") ))

  # Compile stats / khs, now with ar: [accepted, rejected]
  stats=$(jq -nc \
    --argjson hs "$hash_json" \
    --arg ver "$CUSTOM_VERSION" \
    --arg ths "$total_hashrate" \
    --argjson bus_numbers "$bus_numbers" \
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    --arg uptime "$uptime" \
    --argjson accepted "$accepted_shares" \
    --argjson rejected "$rejected_shares" \
    '{ hs: $hs,
       hs_units: "khs",
       algo : "nock",
       ver: $ver,
       $uptime,
       $bus_numbers,
       $temp,
       $fan,
       ar: [$accepted, $rejected] }'
  )

  # Sum of per-GPU hashrates → convert to kH/s
  khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)

else
  khs=0
  stats="null"
  accepted_shares=0
  rejected_shares=0
fi

echo Debug info:
echo Log file : "$LOG_FILE"
echo Time since last log entry : "$diffTime"
echo Raw stats : "$stats_raw"
echo KHS : "$khs"
echo Accepted : "$accepted_shares"
echo Rejected : "$rejected_shares"
echo Output : "$stats"

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
