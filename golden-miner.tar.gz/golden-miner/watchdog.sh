#!/usr/bin/env bash

####################################################################################
###
### golden-miner Watchdog
### Monitors miner log and restarts on issues
###
####################################################################################

# Set working directory more reliably
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || {
    echo "ERROR: Failed to change to script directory: $SCRIPT_DIR"
    exit 1
}

# Load configuration
. ./h-manifest.conf

# Watchdog settings
WATCHDOG_INTERVAL=90  # Check every 1.5 minutes
LOG_LINES_TO_CHECK=10 # Check last 10 lines
PROBLEM_STRING="WARN Proof channel full"

# CUSTOM_LOG_BASENAME already contains full path, just add extensions
WATCHDOG_LOG="${CUSTOM_LOG_BASENAME}_watchdog.log"
MINER_LOG="${CUSTOM_LOG_BASENAME}.log"

# Create log directory if it doesn't exist
LOG_DIR="$(dirname "$WATCHDOG_LOG")"
mkdir -p "$LOG_DIR" 2>/dev/null || {
    echo "ERROR: Failed to create log directory: $LOG_DIR"
    echo "Trying to use local directory..."
    WATCHDOG_LOG="${SCRIPT_DIR}/watchdog.log"
    MINER_LOG="${SCRIPT_DIR}/miner.log"
}

# Function for safe logging
log_message() {
    local message="$1"
    echo "$message"
    if [[ -w "$(dirname "$WATCHDOG_LOG")" ]]; then
        echo "$message" >> "$WATCHDOG_LOG"
    fi
}

log_message "$(date '+%Y-%m-%d %H:%M:%S') - Watchdog started for ${CUSTOM_NAME}"
log_message "$(date '+%Y-%m-%d %H:%M:%S') - Script directory: $SCRIPT_DIR"
log_message "$(date '+%Y-%m-%d %H:%M:%S') - Current directory: $(pwd)"
log_message "$(date '+%Y-%m-%d %H:%M:%S') - Monitoring file: ${MINER_LOG}"
log_message "$(date '+%Y-%m-%d %H:%M:%S') - Looking for string: ${PROBLEM_STRING}"
log_message "$(date '+%Y-%m-%d %H:%M:%S') - Check interval: ${WATCHDOG_INTERVAL} seconds"

# Main monitoring loop
while true; do
    sleep $WATCHDOG_INTERVAL
    
    # Check if log file exists
    if [[ ! -f "$MINER_LOG" ]]; then
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - WARN: Log file not found: $MINER_LOG"
        continue
    fi
    
    # Get last lines from log
    last_lines=$(tail -n $LOG_LINES_TO_CHECK "$MINER_LOG" 2>/dev/null)
    
    if [[ -z "$last_lines" ]]; then
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - WARN: Log file is empty or inaccessible"
        continue
    fi
    
    # Check for problem string
    if echo "$last_lines" | grep -q "$PROBLEM_STRING"; then
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: Problem detected in log!"
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - Found string: ${PROBLEM_STRING}"
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - Restarting miner..."
        
        # Restart miner
        miner restart
        
        if [[ $? -eq 0 ]]; then
            log_message "$(date '+%Y-%m-%d %H:%M:%S') - SUCCESS: Miner restarted successfully"
        else
            log_message "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: Failed to restart miner"
        fi
        
        # Wait longer after restart
        sleep 60
    else
        log_message "$(date '+%Y-%m-%d %H:%M:%S') - OK: No problems detected"
    fi
done
